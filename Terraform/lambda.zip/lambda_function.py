import boto3
import csv
import io
import os
import traceback

s3 = boto3.client('s3')
sns = boto3.client('sns')

def lambda_handler(event, context):
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key    = event['Records'][0]['s3']['object']['key']

        obj = s3.get_object(Bucket=bucket, Key=key)
        content = obj['Body'].read().decode('utf-8').splitlines()

        reader = csv.DictReader(content)
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=reader.fieldnames)

        writer.writeheader()
        for row in reader:
            # Example transformation
            row['Status'] = 'Processed'
            writer.writerow(row)

        s3.put_object(
            Bucket=os.environ['DEST_BUCKET'],
            Key=f"processed/{key}",
            Body=output.getvalue()
        )
    except Exception as e:
        error_message = f"Lambda Failed: {str(e)}\nTraceback: {traceback.format_exc()}"
        sns.publish(
            TopicArn=os.environ['SNS_TOPIC'],
            Subject="Lambda Failure Alert",
            Message=error_message
        )
        raise e
