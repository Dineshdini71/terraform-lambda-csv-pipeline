import unittest
from unittest.mock import patch, MagicMock
import os
import lambda_function
import boto3

class TestLambdaCSVProcessor(unittest.TestCase):
    def setUp(self):
        os.environ['DEST_BUCKET'] = 'destination-bucket'
        os.environ['SNS_TOPIC'] = 'arn:aws:sns:us-east-1:123456789012:lambda-alert'

@patch('lambda_function.boto3.client')
# @patch('lambda_function.s3')
def test_lambda_handler_success(self, mock_boto_client):
    # Setup fake CSV content
    mock_s3 = MagicMock()
    mock_sns = MagicMock()
    mock_boto_client.side_effect = lambda service: {
        's3':mock_s3,
        'sns':mock_sns
    }[service]
    mock_body = MagicMock()
    mock_body.return_value = b'Name,Age\nJohn,30\nJane,25'
    mock_s3.get_object.return_value = {'Body':mock_body}

    # Mock event
    event = {
        'Records': [{
            's3': {
                'bucket': {'name': 'source-bucket'},
                'object': {'key': 'test.csv'}
            }
        }]
    }

    lambda_function.lambda_handler(event, None)
    mock_s3.put_object.assert_called()


